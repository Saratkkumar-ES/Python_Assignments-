{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 1,
   "id": "728112ba-2530-4b3e-9ce2-80bf0668b340",
   "metadata": {},
   "outputs": [],
   "source": [
    "class Employee:\n",
    "    def __init__(self, name, salary):\n",
    "        self.name = name\n",
    "        self.salary = salary\n",
    "\n",
    "    def get_name(self):\n",
    "        return self.name\n",
    "\n",
    "    def get_salary(self):\n",
    "        return self.salary"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "59fac2ef-731a-407f-bc7c-5c525b6d61db",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python [conda env:base] *",
   "language": "python",
   "name": "conda-base-py"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.12.7"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
